// index.js
const WebsiteCrawlerConfig = require('./WebsiteCrawlerConfig');
const WebsiteCrawlerClient = require('./WebsiteCrawlerClient');

module.exports = {
  WebsiteCrawlerConfig,
  WebsiteCrawlerClient
};
